using System;

namespace ClassAndObject_3
{
    public class Human
    {
        //Class Members

        public string name = "Brain Mentors"; // Variable/Data Member/Field/Attribute
        public int age = 25; // Variable/Data Member/Field/Attribute

        public void showData() // Method / Function / Member Function
        {
            Console.WriteLine(name);
            Console.WriteLine(age);
        }
    }
}