﻿using System;

namespace ClassAndObject_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Human Pankaj = new Human();
            Pankaj.showData();

            Human Rahul = new Human();
            Rahul.showData();
        }
    }
}
