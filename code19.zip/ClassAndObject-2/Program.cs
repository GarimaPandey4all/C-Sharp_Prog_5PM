﻿using System;

namespace ClassAndObject_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Color obj = new Color();
            Console.WriteLine(obj.color);
            Console.WriteLine(obj.color2);
        }
    }
}
