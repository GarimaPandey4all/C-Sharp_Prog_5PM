namespace ClassAndObject_2
{
    public class Color
    {
        public string color = "Yellow"; // public and private : access modifiers/specifiers

        public string color2 = "red";
    }
}