﻿using System;

namespace ClassAndObject
{
    class Program
    {
        string text = "Hello"; // Attribute / Data Member

        static void Main(string[] args) // Function/ Method / Member function
        {
           Program obj = new Program(); 
           Console.WriteLine(obj.text);

           Program obj1 = new Program(); 
           Console.WriteLine(obj1.text);
        }
    }
}
