﻿using System;

namespace String_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a = 10, b = 20;

            //Console.WriteLine(a + b);

            string a = "10", b = "20";

            Console.WriteLine(a + b);
        }
    }
}
