﻿using System;

namespace String_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Double Quotes - \"

            string msg = "This is \"C#\" \nClass."; // \n - New Line

            Console.WriteLine(msg);

            //Single Quote - \'

            string msg2 = "What\'s Your\tName\t?"; // \t - Tab

            Console.WriteLine(msg2);

            //BackSlash - \'

            string msg3 = "\\ It is Backslash \b!"; // \b - backspace

            Console.WriteLine(msg3);

        }
    }
}
