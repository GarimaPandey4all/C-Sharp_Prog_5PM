﻿using System;

namespace DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            char ch = 'A';
            float c = 34.56F;
            double d = 37.89;
            string name = "Brain";
            bool state = true;

            /*
            Console.WriteLine(a);
            Console.WriteLine(ch);
            Console.WriteLine(c);
            Console.WriteLine(d);
            Console.WriteLine(name);
            Console.WriteLine(state);
            */

            Console.Write("{0}  {1}  {2}  {3}  {4}  {5}", a, ch, c, d, name, state);
        }
    }
}
