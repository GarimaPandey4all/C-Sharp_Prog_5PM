﻿using System; //System - Namespace - Collection of Classes

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args) // () Parenthesis - Method/Function // Main() -- Entry Point
        {
            Console.WriteLine("Brain"); // ; - semicolon - End of the line
        }
    }
}
