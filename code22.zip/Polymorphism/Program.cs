﻿using System;

namespace Polymorphism
{
    class Animal // Base Class
    {
        public virtual void animalSound()
        {
            Console.WriteLine("Animal Sound");
        }
    }

    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog Sound");
        }
    }

    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat Sound");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Polymorsphism: Many forms: e.g: person-> trainer, employee, brother, son etc
            Animal animal = new Animal(); // Animal Object
            Animal dog = new Dog(); // Dog Object
            Animal cat = new Cat(); // Cat Object

            animal.animalSound();
            dog.animalSound();
            cat.animalSound();
        }
    }
}
