﻿using System;

namespace Abstraction
{
    //Abstract class: It is a restricted class that can't be used to craete objects to access it, it must be inherited
    //from another class.
    abstract class Animal
    {
        public abstract void animalSound(); // does not hava a body

        //Normal method

        public void legs()
        {
            Console.WriteLine("xyz");
        }
    }

    class Dog : Animal{
        
        public override void animalSound()
        {
            Console.WriteLine("Dog Sound");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Abstraction: It is the process in which we can hide the sensitive data from the users.
            //And share only essential information to the user.

            Dog dog = new Dog();
            dog.animalSound();
            dog.legs();
        }
    }
}
