﻿using System;

namespace TypeConversion_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Your age is:" +age);
        }
    }
}
