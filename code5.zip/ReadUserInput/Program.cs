﻿using System;

namespace ReadUserInput
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Name:");
            string name = Console.ReadLine(); //It is used to take user input at runtime.

            Console.WriteLine("Your Name is:" +name);
        }
    }
}
