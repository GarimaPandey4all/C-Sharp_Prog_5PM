﻿using System;

namespace TypeConversion_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Explicitly-2 Convertion
            //Type Conversion Methods/built-in Type Conversion Methods

            /*
                Convert.ToBoolean
                Convert.ToDouble
                Convert.ToString
                Convert.ToInt32(int: 4 bytes- 32 bits)
                Convert.ToInt64(long: 8 bytes- 64 bits)
            */

            int a = 10;
            double d = 45.89;
            bool state = true;

            Console.WriteLine(Convert.ToString(a)); // int to string
            Console.WriteLine(Convert.ToDouble(a)); // int to double
            Console.WriteLine(Convert.ToInt32(d)); // double to int
            Console.WriteLine(Convert.ToString(state)); // bool to string
        }
    }
}
