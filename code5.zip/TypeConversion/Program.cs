﻿using System;

namespace TypeConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            //Type Conversion or Type Casting: Converting one data type into another type.

            /*
                Two types of type casting:

                1. Implicit Type Casting/ Automatically
                -Converting a smaller type to a larger type

                Example: char(2 bytes: 16 bits) -> int(4 bytes: 32 bits)

                2. Explicit Type Casting/ Manually
                -Converting a larger type to a smaller type

                Example: double(8 bytes: 64 bits) -> int(4 bytes: 32 bits)
            
            */

            //Implicit Casting

            int a = 10;
            double d = a; // Automatically

            Console.WriteLine(a);
            Console.WriteLine(d);

            //Explicit Casting

            double f = 35.68;
            int b = (int)f; // Manually

            Console.WriteLine(f);
            Console.WriteLine(b);
        }
    }
}
