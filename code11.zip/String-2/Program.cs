﻿using System;

namespace String_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Brain Mentors";

            int pos = name.IndexOf("M");

            string subString = name.Substring(pos);

            Console.WriteLine(subString);
        }
    }
}
