﻿using System;

namespace String
{
    class Program
    {
        static void Main(string[] args)
        {
            //String = Store text = Collection of Characters : "Hello"

            string name = "Brain Mentors";

            Console.WriteLine(name);

            Console.WriteLine(name.Length); // Length = String Length

            Console.WriteLine(name.ToLower());

            Console.WriteLine(name.ToUpper());

            //Concatenation = Joining = +

            string firstName = "Brain";
            string lastName = "Mentors";

            //string fullName = firstName + lastName; // + --> Concatenation/Joning

            //string fullName = string.Concat(firstName, lastName);

            //Console.WriteLine(fullName);

            //String Interpolation

            string fullName = $"full name is: {firstName} {lastName}";

            Console.WriteLine(fullName);

            string text = "Hello";

            Console.WriteLine(text[2]); // []--> square bracket/subscript operator // 0, 1, ..4 = index number

            //IndexOf()

            Console.WriteLine(text.IndexOf("l"));
        }
    }
}
