﻿using System;

//Declaration of delegate
delegate int NumberChanger(int n);

namespace delegate_2
{
    class Program
    {
        static int num = 10;

        public static int Add(int a)
        {
            num += a; // 10 + 20 = 30
            return num;
        }

        
        public static int Mul(int a)
        {
            num *= a; // 30 * 5 = 150 
            return num;
        }

        public static int display()
        {
            return num;
        }

        static void Main(string[] args)
        {
            /*
                Delegates are similar to pointers to functions in C or C++.
                A delegates is a reference/address type variable that holds the reference to a method.
                The reference/address can be changed at runtime.          
            */
            //Delegate Instantiate
            NumberChanger obj;
            NumberChanger obj1 = new NumberChanger(Add);
            NumberChanger obj2 = new NumberChanger(Mul);

            obj = obj1;
            obj += obj2; // obj = obj + obj2;

            //Multicasting Calling
            obj(10);
            Console.WriteLine("Value of number is:"+display());
        }
    }
}
