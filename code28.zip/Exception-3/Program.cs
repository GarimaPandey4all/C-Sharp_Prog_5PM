﻿using System;

namespace Exception_3
{
    class Program
    {
        static void findAge(int age)
        {
            if(age < 20)
            {
                throw new ArithmeticException("Not matched with the age limit");
            }

            else
            Console.WriteLine("Matched with the age limit");
        }

        static void Main(string[] args)
        {  
            /*
                throw: The throw statement allows you to create a custom error.

                Predefined Exceptions classes in C#:

                1. ArithmeticException
                2. IndexOutofRangeException
                3. FilesNotFoundException
            */

            findAge(19);            
        }
    }
}
