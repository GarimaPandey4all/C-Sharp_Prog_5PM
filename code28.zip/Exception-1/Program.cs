﻿using System;

namespace Exception_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Exceptions: abnormal condition which occurs at runtime or runtime errors

                try and catch:

                try: The try statement allows you to declare block of code to be tested for errors while it is being
                executed.

                catch: The catch statement allows you to define a block of code to be executed, if an error occurs in the
                try block.

                try
                {

                }

                catch(Exception e)
                {

                }
            */

            try
            {
                int[] digits = {10, 20, 30, 40, 50};
                Console.WriteLine(digits[6]);

               Console.WriteLine("Try Block");
            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                //Console.WriteLine("Index out of Range");
            }
        }
    }
}
