﻿using System;

namespace ThisKeyword
{
    class VarAssign
    {
        int a, b;

        public VarAssign(int a, int b)
        {
            this.a = a;
            this.b = b;
        }

        public void display()
        {
            Console.WriteLine("{0} and {1}", a, b);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            VarAssign obj = new VarAssign(10, 20);

            obj.display();
        }
    }
}
