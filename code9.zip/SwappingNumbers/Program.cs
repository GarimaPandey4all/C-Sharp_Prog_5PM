﻿using System;

namespace SwappingNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any number for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any number for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            //Swapping/ Exchange: a = 5, b = 7 :After Swapping : a = 7, b = 5

            //Swapping by using third variable

            int temp;

            temp = a;
            a = b;
            b = temp;

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);
        }
    }
}
