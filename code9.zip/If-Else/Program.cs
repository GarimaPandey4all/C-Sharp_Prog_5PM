﻿using System;

namespace If_Else
{
    class Program
    {
        static void Main(string[] args)
        {
            //Decision/Conditional Statements

            /*
                1. If-Else
                2. If-Else If-Else
                3. Switch

                Conditional/Ternary Operator            
            */

            //If-Else

            int number, remainder;

            Console.WriteLine("Enter any number:");
            number = Convert.ToInt32(Console.ReadLine());

            remainder = number % 2;

            if(remainder == 0)
            Console.WriteLine("Number is Even");
            else
            Console.WriteLine("Number is Odd");
        }
    }
}
