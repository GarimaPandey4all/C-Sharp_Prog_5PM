﻿using System;

namespace SwappingNumbers_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any number for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any number for b:");
            b = Convert.ToInt32(Console.ReadLine());

            /*
            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            //First-Way: + and - 

            a = a + b; // a = 4, b = 9: a = 4 + 9 = 13
            b = a - b; // b = 13 - 9 = 4 
            a = a - b; // a = 13 - 4 = 9

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);
            */

            /*
            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            //Second-Way: * and / 

            a = a * b; // a = 4, b = 9: a = 4 * 9 = 36
            b = a / b; // b = 36 / 9 = 4 
            a = a / b; // a = 36 / 4 = 9

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);
            */

            Console.WriteLine("Before Swapping the value of a={0} and b={1}", a, b);

            //Third-Way: X-OR ^ 

            a = a ^ b; // a = 4, b = 9: a = 4 ^ 9 = 13
            b = a ^ b; // b = 13 ^ 9 = 4 
            a = a ^ b; // a = 13 ^ 4 = 9

            Console.WriteLine("After Swapping the value of a={0} and b={1}", a, b);
        }
    }
}
