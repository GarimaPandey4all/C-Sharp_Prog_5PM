﻿using System;

namespace Conditional_TernaryOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Conditional/Ternary Operator - ? :

                Ternary: 3

                (Condition) ? True : False

                (Expression-1) ? Expression-2 : Expression-3
            
            */

            int number;
            
            Console.WriteLine("Enter any number:");
            number = Convert.ToInt32(Console.ReadLine());

            string msg = ((number % 2) == 0) ? "Number is Even" : "Number is Odd";

            Console.WriteLine(msg);
        }
    }
}
