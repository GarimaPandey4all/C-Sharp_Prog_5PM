﻿using System;

namespace SymmetricMatrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[5, 5];
            int[,] temp = new int[5, 5];

            Console.WriteLine("Enter number of rows:");
            int rows = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter number of columns:");
            int columns = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter values in Matrix:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix are:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine();
            }

            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    temp[j, i] = matrix[i, j];
                }
            }

            Console.WriteLine("Transpose Matrix is:");
            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    Console.Write("{0}\t", temp[i, j]);
                }
                Console.WriteLine();
            }

            int count = 1; // 1 means it is symmetric matrix

            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < columns; j++)
                {
                    if(temp[i, j] != matrix[i, j])
                    {
                        count++;
                        break;
                    }
                }
            }

            if(count == 1)
            {
                Console.WriteLine("Symmetric Matrix");
            }
            else
            {
                Console.WriteLine("Not a Symmetric Matrix");
            }
        }
    }
}
