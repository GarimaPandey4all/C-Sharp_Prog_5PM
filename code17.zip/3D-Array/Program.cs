﻿using System;

namespace _3D_Array
{
    class Program
    {
        static void Main(string[] args)
        {
           int[,,] array = new int[2, 2, 2];

            Console.WriteLine("Enter values in 3D-Array:");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    for(int k = 0; k < 2; k++)
                    array[i, j, k] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in 3D-Array are:");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    for(int k = 0; k < 2; k++)
                    Console.Write("{0}\t", array[i, j, k]);
                }
            }
        }
    }
}