﻿using System;

namespace Properties
{   
    class Human
    {
        private string name; // variable // field

        public string Name // property
        {
            get{
                return name; // return Pankaj;
            }
            set{
                name = value; // name = "Pankaj";
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Properties: A property is like a combination of a variable and method/function and it has two menthods
            //a get and a set method.

            Human obj = new Human();
            obj.Name = "Pankaj";

            Console.WriteLine(obj.Name);
        }
    }
}
