using System;

namespace Properties_2
{
    public class Human
    {
        private string name; // variable // field

        public string Name // property
        {
            get{
                return name; // return Pankaj;
            }
            set{
                name = value; // name = "Pankaj";
            }
        }
    }
}