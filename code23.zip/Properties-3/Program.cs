﻿using System;

namespace Properties_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();
            obj.Name = "Pankaj";

            Console.WriteLine(obj.Name);
        }
    }
}
