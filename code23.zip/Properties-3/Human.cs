using System;

namespace Properties_3
{
    public class Human
    {
        //private string name; // variable // field

        public string Name // property
        {
            get;
            set;
        }
    }
}