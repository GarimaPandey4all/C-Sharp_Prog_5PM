﻿using System;

namespace function_4
{
    class Program
    {
        //4. Function without arguments and with return value

        static int Sum() // int a, int b- function parameters/ formal arguments
        {
            int a, b;

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("Addition is: "+ (a + b));
            return (a + b);
        }

        static void Main(string[] args)
        {
            int sum = Sum();
            Console.WriteLine("Addition is: "+sum);
            
            sum = Sum();
            Console.WriteLine("Addition is: "+sum);
        }
    }
}
