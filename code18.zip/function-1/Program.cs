﻿using System;

namespace function_1
{
    class Program
    {
        //1. Function without arguments and without return value

        //function: void- no return value
        static void HelloWorld() // function definition
        {
            //code block
            Console.WriteLine("Hello World");
        }

        static void Main(string[] args)
        {
            //function calling
            HelloWorld();
            HelloWorld();
            HelloWorld();
            HelloWorld();
            HelloWorld();
        }
    }
}
