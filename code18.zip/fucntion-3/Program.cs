﻿using System;

namespace fucntion_3
{
    class Program
    {
        //2. Function with arguments and with return value

        static int Sum(int a, int b) // int a, int b- function parameters/ formal arguments
        {
            //Console.WriteLine("Addition is: "+ (a + b));
            return (a + b);
        }

        static void Main(string[] args)
        {
            int sum = Sum(10, 20); // 10, 20- function arguments/actual arguments
            Console.WriteLine("Addition is: "+sum);
            
            sum = Sum(30, 50);
            Console.WriteLine("Addition is: "+sum);
        }
    }
}
