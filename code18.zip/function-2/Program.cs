﻿using System;

namespace function_2
{
    class Program
    {
        //2. Function with arguments and without return value

        static void Sum(int a, int b) // int a, int b- function parameters/ formal arguments
        {
            Console.WriteLine("Addition is: "+ (a + b));
        }

        static void Main(string[] args)
        {
            Sum(10, 20); // 10, 20- function arguments/actual arguments
            Sum(30, 50);
        }
    }
}
