﻿using System;

namespace Array_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix1 = new int[2, 3];
            int[,] matrix2 = new int[2, 3];
            int[,] result = new int[2, 3];

            Console.WriteLine("Enter any values in Matrix-1");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    matrix1[i, j]  = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Enter any values in Matrix-2");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    matrix2[i, j]  = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix-1 are:");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", matrix1[i, j]);
                }
                Console.WriteLine();
            }

            Console.WriteLine("Values in Matrix-2 are:");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", matrix2[i, j]);
                }
                Console.WriteLine();
            }

            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    result[i, j] = matrix1[i, j] + matrix2[i, j];
                }
            }

            Console.WriteLine("Addition is:");
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", result[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
