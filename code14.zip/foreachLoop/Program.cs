﻿using System;

namespace foreachLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            //foreachLoop: it is used to read the array.
            //Array: It is used to store the multiple values of a similar type in single variable.

            string[] books = {"C#", "C", "JavaScript"}; // Array Declare and Initialize

            foreach(string i in books)
            {
                Console.WriteLine(i);
            }
        }
    }
}
