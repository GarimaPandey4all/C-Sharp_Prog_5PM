﻿using System;

namespace Continue
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i <= 10; i++)
            {
                if(i == 7)
                {
                    continue;
                }

                Console.WriteLine(i);
            }
        }
    }
}
