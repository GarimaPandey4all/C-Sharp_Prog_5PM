﻿using System;

namespace Constructor_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Human p1 = new Human("Pankaj", 25, 001);
            Human p2 = new Human("Rahul", 21, 023);

            Console.WriteLine("{0} {1}", p1.id, p1.name);
            Console.WriteLine("{0} {1}", p2.id, p2.name);
        }
    }
}
