using System;

namespace Constructor_3
{
    public class Human
    {
        public string name;
        public int age;
        public int id;

        public Human(string personName, int personAge, int personId) // Constructor Parameterized
        {
            name = personName;
            age = personAge;
            id = personId;
        }
    }
}