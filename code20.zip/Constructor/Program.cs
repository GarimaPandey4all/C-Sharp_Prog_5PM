﻿using System;

namespace Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Constructor: It is a special type of method/function because class name and constructor name both are same.
                It is called automatically when an object of a class is created. 
                And it is used to initialize the instance variable.
            **/

            Car Honda = new Car(); // here automatically this line call the constructor
            Console.WriteLine(Honda.model);
        }
    }
}
