using System;

namespace Constructor
{
    public class Car
    {
        public string model;

        public Car() // Constructor
        {
            model = "XUV"; // initialization instance variable
        }
    }
}