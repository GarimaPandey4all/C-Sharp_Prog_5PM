using System;

namespace Constructor_2
{
    public class Car
    {
        public string model;

        public Car(string modelName) // Constructor Parameterized
        {
            model = modelName; // initialization instance variable
        }
    }
}