﻿using System;

namespace Constructor_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Car Honda = new Car("XUV");
            Console.WriteLine(Honda.model);
        }
    }
}
