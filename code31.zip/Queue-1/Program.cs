﻿using System;
using System.Collections;

namespace Queue_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue obj = new Queue();

            //Insert in an Queue

            obj.Enqueue('A');
            obj.Enqueue('B');
            obj.Enqueue('C');
            obj.Enqueue('D');
            obj.Enqueue('E');

            Console.WriteLine("Queue is:");
            foreach(char ch in obj)
            {
                Console.Write(ch + " ");
            }

            Console.WriteLine();

            obj.Dequeue();
            Console.WriteLine("Queue is:");
            foreach(char ch in obj)
            {
                Console.Write(ch + " ");
            }
        }
    }
}
