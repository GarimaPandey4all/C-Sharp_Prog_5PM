﻿using System;
using System.Collections;

namespace hashtable
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable obj = new Hashtable();

            //Insert in an Hashtable

            obj.Add("100", "Rishi");
            obj.Add("101", "Rahul");
            obj.Add("102", "Pankaj");
            obj.Add("103", "Jyoti");
            obj.Add("104", "Ekta");
            //obj.Add("105", "Shivam");

            if(obj.ContainsValue("Shivam"))
                Console.WriteLine("He is already in an hashtable");

            else
            obj.Add("105", "Shivam");

            //Get a collection of keys
            ICollection key = obj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + " : " + obj[str]);
        }
    }
}
