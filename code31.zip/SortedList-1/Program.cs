﻿using System;
using System.Collections;

namespace SortedList_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //SortedList : It is a combination of ArrayList(Access by index value) and Hashtable(Access by key-value pair)
            //It is always access the values in an ascending order.

            SortedList obj = new SortedList();

            //Insert into a sorted list

            obj.Add("500", "Rihsi");
            obj.Add("300", "Rahul");
            obj.Add("200", "Pankaj");
            obj.Add("600", "Jyoti");
            obj.Add("400", "Ram");

            if(obj.ContainsValue("Mentors"))
            Console.WriteLine("Already Available");
            else
            obj.Add("450", "Mentors");

            ICollection key = obj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + " : " + obj[str]);
        }
    }
}
