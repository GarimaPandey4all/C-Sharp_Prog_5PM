﻿using System;

namespace BitwiseOperators_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a << 1); // 10
            Console.WriteLine(a >> 1); // 2
        }
    }
}
