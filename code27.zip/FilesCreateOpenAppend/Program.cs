﻿using System;
using System.IO;

namespace FilesCreateOpenAppend
{
    class Program
    {
        static void Main(string[] args)
        {
            //Files: CRUD: Create Read Update Delete
            string myFile = @"test.txt";

            using(StreamWriter writeText = File.CreateText(myFile))
            {
                Console.WriteLine("Hello!");
                Console.WriteLine("Welcome to Brain Mentors");
            }
            
            using(StreamWriter writeText = File.AppendText(myFile)) // Append : write content at the end of the file
            {
                Console.WriteLine("How are you?");
            }

            using(StreamReader text = File.OpenText(myFile))
            {
                string readText = "";
                while((readText = text.ReadLine()) != null)
                {
                    Console.WriteLine(readText);
                }
            }
        }
    }
}
