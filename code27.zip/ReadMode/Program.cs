﻿using System;
using System.IO;

namespace ReadMode
{
    class Program
    {
        static void Main(string[] args)
        {   //Files in C# : Get data from the file
            // The file class from the System.IO namespace, allows us to work with files.

            string readText = File.ReadAllText("test.txt"); // Read Content from the file

            Console.WriteLine(readText);
        }
    }
}
