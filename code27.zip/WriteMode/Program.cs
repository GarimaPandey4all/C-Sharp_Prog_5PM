﻿using System;
using System.IO;

namespace WriteMode
{
    class Program
    {
        static void Main(string[] args)
        {
            // put data into the file
            string writeText = "Hi... How are you? Pankaj";
            File.WriteAllText("test.txt", writeText);

            Console.WriteLine("Content inserted successfully in a file");
        }
    }
}
