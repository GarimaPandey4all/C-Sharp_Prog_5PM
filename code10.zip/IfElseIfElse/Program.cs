﻿using System;

namespace IfElseIfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            //Largest Number b/w 3 numbers

            Console.WriteLine("Enter value for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for c:");
            int c = Convert.ToInt32(Console.ReadLine());
            
            if((a > b) && (a > c))
            Console.WriteLine("Largest Number is:" +a);
            else if(b > c)
            Console.WriteLine("Largest Number is:" +b);
            else
            Console.WriteLine("Largest Number is:" +c);
        }
    }
}
