﻿using System;

namespace TernaryOperator_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter value for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for c:");
            int c = Convert.ToInt32(Console.ReadLine());

            int largest = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);

            Console.WriteLine("Largest Number is:" +largest);
        }
    }
}
