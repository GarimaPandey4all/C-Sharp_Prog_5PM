﻿using System;

namespace BitwiseOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a & b);
            Console.WriteLine(a | b);
            Console.WriteLine(a ^ b);
        }
    }
}
