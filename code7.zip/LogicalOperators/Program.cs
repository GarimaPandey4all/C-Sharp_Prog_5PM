﻿using System;

namespace LogicalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            //Logical Operators

            /*
                1. Logical AND operator

                    &&
                
                2. Logical OR operator

                    ||

                3. Logical Not operator

                    !
            */

            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a > b && a > 10);
            Console.WriteLine(a > b || a > 10);
            Console.WriteLine(!(a > b && a > 10));
        }
    }
}
