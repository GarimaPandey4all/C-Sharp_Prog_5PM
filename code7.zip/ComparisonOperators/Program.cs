﻿using System;

namespace ComparisonOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(a==b);
            Console.WriteLine(a!=b);
            Console.WriteLine(a>b);
            Console.WriteLine(a<b);
            Console.WriteLine(a>=b);
            Console.WriteLine(a<=b);
        }
    }
}
