﻿using System;

namespace Switch_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Switch - Menu Driven Program

             int a = 10, b = 20;

            //Loop : Repetition

            while(true)
            {

            Console.WriteLine("Press 1. Addition");
            Console.WriteLine("Press 2. Subtraction");
            Console.WriteLine("Press 3. Multiplication");
            Console.WriteLine("Press 4. Division");
            Console.WriteLine("Enter your choice");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1:
                Console.WriteLine(a + b);
                break;

                case 2:
                Console.WriteLine(a - b);
                break;

                case 3:
                Console.WriteLine(a * b);
                break;

                case 4:
                Console.WriteLine(a / b);
                break;

                default:
                Console.WriteLine("Invalid Choice");
                break;
            }
        }
        }
    }
}
