﻿using System;

namespace WhileLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;

            while(i <= 10)
            {
                Console.WriteLine("Counter is:"+i);
                i++;
            }
        }
    }
}
