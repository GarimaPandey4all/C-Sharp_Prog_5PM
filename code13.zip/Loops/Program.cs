﻿using System;

namespace Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Loops: Three Types of Loops : If you want to execute definite numner of times is called a loop.

                1. For Loop

                for(int i = 1; i<=10; i++)
                {
                    //Block of for Loop
                }

                2. While Loop

                int i = 1;

                while(i <= 10)
                {
                    //Block of while Loop
                }

                3. Do-While Loop

                int i = 1;

                do
                {
                    //Block of Do-While Loop
                }while(i <= 10);
            
            */

            for(int i = 1; i <= 10; i++)
            {
                 Console.WriteLine("Hello World");
            }
        }
    }
}
