﻿using System;

namespace ArithmeticOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for =b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition of {0} and {1} is: {2}", a, b, (a+b));
            Console.WriteLine("Subtraction is:"+(a-b));
            Console.WriteLine("Multiplication is:"+(a*b));
            Console.WriteLine("Division is:"+(a/b));
            Console.WriteLine("Modulus is:"+(a%b)); // Modulus: It gives remainder.

            //Pre and Post Increment
            Console.WriteLine("Pre-Increment is:" +(++a)); // a = 5; a = 5 + 1 = 6
            Console.WriteLine("Post-Increment is:" +(a++)); // a = 6
            Console.WriteLine("a is:" +a); // a = 7

            //Pre and Post Decrement
            Console.WriteLine("Pre-Decrement is:" +(--b)); // b = 9; b = 9 - 1 = 8
            Console.WriteLine("Post-Decrement is:" +(b--)); // b = 8
            Console.WriteLine("b is:" +b);
        }
    }
}
