﻿using System;

namespace VariableAndConstant
{
    class Program
    {
        static void Main(string[] args)
        {
            const int d = 50;  // const = constant = fixed value

            //error d = 70; // re-initialize

            Console.WriteLine(d);
        }
    }
}
