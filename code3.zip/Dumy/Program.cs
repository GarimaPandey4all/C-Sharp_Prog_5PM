﻿using System;

namespace Dumy
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This is C# Batch."); // "" -- string -- Collection of characters 

            //Console/Terminal: Output Screen
        }
    }
}
