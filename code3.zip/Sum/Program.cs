﻿using System;

namespace Sum
{
    class Program
    {
        static void Main(string[] args)
        {
            //Addition two numbers

            int a = 10, b = 20; // a ,  b : Declare/Create and Initialize/Define/Assign

            a = 30; // Re-assign

            int c = a + b;

            Console.WriteLine("Addition of two numbers is:" +c); // + --> Concatenation/Joining    
            
            //Comments : Always ignored by compiler.
            /* Multiple Line Comment 
                Name: Brain Mentors
                Date: 13-09-2020
                Last Modified: 12:30 PM
            */
        }
    }
}
