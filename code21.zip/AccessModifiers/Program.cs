﻿using System;

namespace AccessModifiers
{
    //Class is an example of Encapsulation.
    class Human
    {
        private string name = "Pankaj";

        static void Main(string[] args)
        {
            Human obj = new Human();
            Console.WriteLine(obj.name);
        }
    }
}
