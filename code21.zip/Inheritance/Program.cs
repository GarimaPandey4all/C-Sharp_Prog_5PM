﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();

            obj.honk(); // Parent class's function

            Console.WriteLine(obj.brand + " " + obj.name);
        }
    }
}
