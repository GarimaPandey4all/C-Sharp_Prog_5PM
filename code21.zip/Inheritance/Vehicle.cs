using System;

namespace Inheritance
{
    public class Vehicle // Parent Class / Base Class
    {
        public string brand = "Honda";

        public void honk()
        {
            Console.WriteLine("pee ppee");
        }
    }
}