using System;

namespace Inheritance
{
    public class Car : Vehicle // : - used to inherit // Car: Child Class / Derived Class
    {
        public string name = "XUV";
    }
}