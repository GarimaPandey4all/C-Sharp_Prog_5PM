﻿using System;

namespace AccessModifiers_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();
            Console.WriteLine(obj.name);
        }
    }
}
