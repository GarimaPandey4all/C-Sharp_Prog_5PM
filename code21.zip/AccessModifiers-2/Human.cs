using System;

namespace AccessModifiers_2
{
    public class Human
    {
        //private string name = "pankaj";  
        //Encapsulation : It is a process in which wrapping up the field and functions together in a single unit(class).
        //Secure Encapsualtion/Abstraction: It make sure that our sensitive data is hidden from users. It is also called the abstraction.

          public string name = "pankaj";
    }
}