﻿using System;

namespace GenericMethod
{
    class Program
    {
        //Generic Method
        static void Swap<T>(T a, T b)
        {
            Console.WriteLine("Before swapping the value of a={0} and b={1}", a, b);

            T temp;

            temp = a; 
            a = b;
            b = temp;

            Console.WriteLine("After swapping the value of a={0} and b={1}", a, b);
        }

        static void Main(string[] args)
        {
            Swap(10, 20); // int
            Swap(23.5f, 45.7f); // float
        }
    }
}
