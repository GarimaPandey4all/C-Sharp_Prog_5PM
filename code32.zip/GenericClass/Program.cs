﻿using System;

namespace GenericClass
{
    //Generic Class
    public class MyGeneric<T>
    {
        private T[] array; //field

        public MyGeneric(int size)
        {
            array = new T[size];
        }

        public T getItem(int index)
        {
            return array[index];
        }

        public void setItem(int index, T value)
        {
            array[index] = value;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Declare int array
            MyGeneric<int> intArray = new MyGeneric<int>(5);

            //Setting values

            for(int i = 0; i < 5; i++)
            intArray.setItem(i, i * 5);

            //Accessing values from array

            for(int i = 0; i < 5; i++)
            Console.Write(intArray.getItem(i) + "  ");

            Console.WriteLine();

            MyGeneric<char> charArray = new MyGeneric<char>(5);

            for(int i = 0; i < 5; i++)
            charArray.setItem(i, (char)(i + 65)); //65 - A

            //Accessing values from array

            for(int i = 0; i < 5; i++)
            Console.Write(charArray.getItem(i) + "  ");

            Console.WriteLine();



        }
    }
}
