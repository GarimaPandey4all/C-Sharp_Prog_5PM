﻿using System;

namespace PrintYourName
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Brain Mentors"); // (//--> Single Line Comment) Print on output screen
        }
    }
}
