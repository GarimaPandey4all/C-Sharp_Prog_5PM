﻿using System;
using System.Collections;

namespace CollectionClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            //Collection Classes are specialized classes for data storage and retrieval. These classes support stack, arrays,
            //linked list and hastables.

            //1. ArrayList: It is an alternative to an array, arraylist resize itself automatically. It allows
            //dynamic memory alllocation.

            ArrayList al = new ArrayList();

            Console.WriteLine("Insertion in Array:");
            al.Add(10);
            al.Add(20);
            al.Add(30);
            al.Add(40);
            al.Add(50);
            al.Add(60);
            al.Add(70);
            al.Add(80);
            al.Add(90);

            Console.WriteLine("Count is:"+ al.Count);
            Console.WriteLine("Capacity is:"+ al.Capacity);

            Console.WriteLine("Values in Array are:");
            foreach(int i in al)
            {
                Console.Write(i + " ");
                Console.WriteLine();
            }

            al.Remove(50);

            Console.WriteLine("Values in Array are:");
            foreach(int i in al)
            {
                Console.Write(i + " ");
                Console.WriteLine();
            }
        }
    }
}
