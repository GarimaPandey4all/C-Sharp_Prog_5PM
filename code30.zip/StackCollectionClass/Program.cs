﻿using System;
using System.Collections;

namespace StackCollectionClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack obj = new Stack();

            //Insert into a Stack

            obj.Push(10);
            obj.Push(20);
            obj.Push(30);
            obj.Push(40);
            obj.Push(50);

            Console.WriteLine("Stack is:");
            foreach(int i in obj)
            Console.Write(i + " ");

            Console.WriteLine();

            Console.WriteLine("Top value is:"+obj.Peek());

            obj.Pop();

            Console.WriteLine("Stack is:");
            foreach(int i in obj)
            Console.Write(i + " ");

            Console.WriteLine();

            obj.Push(50);

            Console.WriteLine("Stack is:");
            foreach(int i in obj)
            Console.Write(i + " ");

            Console.WriteLine();        
        }
    }
}
