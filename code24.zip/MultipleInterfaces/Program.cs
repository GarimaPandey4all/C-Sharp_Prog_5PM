﻿using System;

namespace MultipleInterfaces
{
    interface IVehicle
    {
        void FourWheeler();
    }

    interface IMotor
    {
        void MotorType();
    }

    class Car : IVehicle, IMotor
    {
        public void FourWheeler()
        {
            Console.WriteLine("Car has four Wheels");
        }

        public void MotorType()
        {
            Console.WriteLine("Car has one Motor");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();
            obj.FourWheeler();
            obj.MotorType();
        }
    }
}
