﻿using System;

namespace Interface
{
    //Interface: Interface is used to implement the multiple interfaces(Multiple Inheritance).
    //Interface: Abstract Class: No need to call interface via object.
    //Abstract Class: Abstract class contain abstract methods(they doesn't have body).

    interface IVehicle
    {
        void FourWheeler(); // Abstract method
    }

    class Car : IVehicle //(Interface must be implement)
    {
        public void FourWheeler()
        {
            Console.WriteLine("Car has four wheels");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();
            obj.FourWheeler();
        }
    }
}
