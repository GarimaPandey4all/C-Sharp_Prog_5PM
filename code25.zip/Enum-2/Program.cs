﻿using System;

namespace Enum_2
{
    class Program
    {
        enum Mixtures
        {
            Weeks = 7, Months = 12, Pi = 22/7
        }

        static void Main(string[] args)
        {
            int week = (int)Mixtures.Weeks;
            Console.WriteLine(week);
            
            int month = (int)Mixtures.Months;
            Console.WriteLine(month);
            
            int pi = (int)Mixtures.Pi;
            Console.WriteLine(pi);
        }
    }
}
