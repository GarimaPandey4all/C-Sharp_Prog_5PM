﻿using System;

namespace Enum
{
    enum Months
    {
        January = 1, Febrary, March, April, May, June, July, August, September, October, November, December
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Enum: Enumeration: Group of Constants
            int month = (int)Months.March; // month = 8
            Console.WriteLine(month);

        }
    }
}
