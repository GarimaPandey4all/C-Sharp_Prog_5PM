﻿using System;

namespace Enum_3
{
    class Program
    {
        enum Week
        {
            Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
        }

        static void Main(string[] args)
        {
            int today = (int)Week.Thursday;
            Console.WriteLine(today);
        }
    }
}
